# Hello, world!
#
# This is an example function named 'hello'
# which prints 'Hello, world!'.
#
# You can learn more about package authoring with RStudio at:
#
#   http://r-pkgs.had.co.nz/
#
# Some useful keyboard shortcuts for package authoring:
#
#   Install Package:           'Ctrl + Shift + B'
#   Check Package:             'Ctrl + Shift + E'
#   Test Package:              'Ctrl + Shift + T'


# Load required packages
library(scater)
library(SingleCellExperiment)
library(scater)
library(SingleCellExperiment)
library(pROC)
library(Seurat)
library(ggplot2)
library(RColorBrewer)
library(gplots)
library(mysyn)
# Required(mysyn)

# Preprocessing steps
# Assuming the single-cell expression matrix dataset is stored in 'sc_dataset'

# Create SingleCellExperiment object
sce <- SingleCellExperiment(assays = list(counts = sc_dataset))

# Normalize the data
sce <- normalize(sce)

# Scale the data
sce <- scale(sce)

# Perform unsupervised clustering
# 'clustering_method' should be a manually selectable clustering method
clustering_method <- "kmeans"  # Change this to your desired clustering method

clustering <- cluster(sce,clustering_method)

# Calculate silhouette coefficients for each cell
silhouette <- silhouette(sce,clustering)

# Calculate the distribution of silhouette coefficients for each category
silhouette_distribution <- tapply(silhouette[, "silhouetteWidth"], silhouette[, "cluster"])

# Find categories with skewed distributions
skewed_categories <- names(silhouette_distribution[abs(skewness(silhouette_distribution)) > 1])

# Extract 30% points from left-tail of skewed categories
oversampled_points <- numeric()
for (category in skewed_categories) {
  category_silhouette <- silhouette[silhouette[, "cluster"] == category, "silhouetteWidth"]
  left_tail_points <- sort(category_silhouette)[1:floor(0.3 * length(category_silhouette))]
  oversampled_points <- c(oversampled_points, left_tail_points)
}

major_data = major_data  #put in your data
minor_data = minor_data  #put in your data

oversampled_data <- over_sampling(major = major_data,minor = minor_data)

# Combine original and oversampled data
combined_data <- rbind(sce$counts, oversampled_data$new_dataset)

# Perform second unsupervised clustering on original and oversampled data
# 'second_clustering_method' should be a manually selectable clustering method
second_clustering_method <- "kmeans"  # Change this to your desired clustering method

second_clustering <- cluster(combined_data, method = second_clustering_method)

# Remove oversampled points from clustering results
final_clustering <- subset(second_clustering, obsNames(second_clustering) %in% rownames(sce$counts))

# Output final clustering results
final_clustering_results <- final_clustering$cluster


# Preprocessing steps
# Assuming the single-cell expression matrix dataset is stored in 'sc_dataset'

# Function to calculate AUC and plot ROC curve if true labels are given
evaluate_classification <- function(final_clustering_results, true_labels) {
  auc <- roc(as.factor(final_clustering_results), true_labels)$auc

  # Plot ROC curve
  roc_curve <- roc(as.factor(final_clustering_results), true_labels)
  plot(roc_curve, main = "ROC Curve", print.auc = TRUE)
}

# Function to filter marker genes and plot heatmaps, violin plots, and marker gene distributions
visualize_results <- function(sce, final_clustering_results) {
  # Assuming marker genes are stored in 'marker_genes'

  # Filter marker genes based on clustering results
  marker_genes <- subset(sce, features = marker_genes, cells = rownames(sce))

  # Plot heatmap
  heatmap(marker_genes, main = "Marker Gene Expression Heatmap",
          col = colorRampPalette(brewer.pal(9, "YlOrRd"))(100),
          scale = "none", show_colnames = FALSE)

  # Plot violin plots
  violin(marker_genes, features = marker_genes, group.by = final_clustering_results,
         main = "Marker Gene Expression Violin Plots",
         col = colorRampPalette(brewer.pal(9, "Set2"))(length(unique(final_clustering_results))))

  # Plot marker gene distributions
  par(mfrow = c(ceiling(sqrt(length(marker_genes))), ceiling(sqrt(length(marker_genes)))))
  for (i in 1:length(marker_genes)) {
    hist(marker_genes[i, ], main = colnames(marker_genes)[i], xlab = "Expression Level",
         col = brewer.pal(9, "Blues"))
  }
}

# Example usage

# True labels for evaluation (assuming stored in 'true_labels')
true_labels <- c(rep("A", 50), rep("B", 50))

# Evaluate classification and plot ROC curve
evaluate_classification(final_clustering_results, true_labels)

# Visualize results
visualize_results(sce, final_clustering_results)
