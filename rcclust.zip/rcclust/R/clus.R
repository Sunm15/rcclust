#' Cluster Single-cell Dataset
#'
#' This function performs unsupervised clustering on a single-cell expression matrix dataset using the specified clustering algorithm.
#'
#' @param sc_dataset A single-cell expression matrix dataset.
#' @param algorithm The clustering algorithm to use (options: "kmeans", "dbscan", "simlr", "sc3").
#' @return Clustering results.
#' @export
cluster <- function(sc_dataset, algorithm) {
  # Check if algorithm is valid
  valid_algorithms <- c("kmeans", "dbscan", "simlr", "sc3")
  if (!(algorithm %in% valid_algorithms)) {
    stop("Invalid clustering algorithm. Please choose from: ", paste(valid_algorithms, collapse = ", "))
  }

  # Preprocess data if necessary

  # Perform clustering based on selected algorithm
  if (algorithm == "kmeans") {
    clustering_results <- kmeans_clustering(sc_dataset)
  } else if (algorithm == "dbscan") {
    clustering_results <- dbscan_clustering(sc_dataset)
  } else if (algorithm == "simlr") {
    clustering_results <- simlr_clustering(sc_dataset)
  } else if (algorithm == "sc3") {
    clustering_results <- sc3_clustering(sc_dataset)
  }

  # Return clustering results
  return(clustering_results)
}

#' Perform K-means Clustering
#'
#' This function performs K-means clustering on the single-cell expression matrix dataset.
#'
#' @param sc_dataset A single-cell expression matrix dataset.
#' @return Clustering results.
kmeans_clustering <- function(sc_dataset,max_clusters = 40) {
  # Perform K-means clustering

    # Compute within-cluster sum of squares for different cluster numbers
    wss <- sapply(1:max_clusters, function(k) {
      kmeans(sc_dataset, centers = k)$tot.withinss
    })

    # Calculate the percentage of variance explained
    variance_explained <- 1 - (wss / sum(wss))

    # Find the "elbow" point where the percentage of variance explained starts to level off
    elbow_point <- 1
    for (i in 2:max_clusters) {
      if (variance_explained[i] - variance_explained[i - 1] < 0.1) {
        elbow_point <- i - 1
        break
      }
    }

    # Perform K-means clustering with the selected number of clusters
    clustering_results <- kmeans(sc_dataset, centers = elbow_point)$cluster


  return(clustering_results)
}

#' Perform DBSCAN Clustering
#'
#' This function performs DBSCAN clustering on the single-cell expression matrix dataset.
#'
#' @param sc_dataset A single-cell expression matrix dataset.
#' @return Clustering results.
dbscan_clustering <- function(sc_dataset,eps = 0.5,minPts = 3) {
  # Perform DBSCAN clustering

    clustering_results <- dbscan::dbscan(sc_dataset, eps = eps, minPts = minPts)

    return(clustering_results)
}

#' Perform SIMLR Clustering
#'
#' This function performs SIMLR clustering on the single-cell expression matrix dataset.
#'
#' @param sc_dataset A single-cell expression matrix dataset.
#' @return Clustering results.
simlr_clustering <- function(sc_dataset,k = 5) {
  # Perform SIMLR clustering

    clustering_results <- SIMLR::simlr(sc_dataset, k = k)$cluster
    return(clustering_results)
}

#' Perform SC3 Clustering
#'
#' This function performs SC3 clustering on the single-cell expression matrix dataset.
#'
#' @param sc_dataset A single-cell expression matrix dataset.
#' @return Clustering results.
sc3_clustering <- function(sc_dataset) {
  # Perform SC3 clustering

    clustering_results <- sc3::sc3_run(sc_dataset, n_clusters = n_clusters)$cluster

    return(clustering_results)
}
