
# Some useful keyboard shortcuts for package authoring:
#
#   Install Package:           'Ctrl + Shift + B'
#   Check Package:             'Ctrl + Shift + E'
#   Test Package:              'Ctrl + Shift + T'

#' Oversampling of Minority Class
#'
#' This function performs oversampling of the minority class in a single-cell expression matrix dataset.
#'
#' @param major A matrix representing the majority class data.
#' @param minor A matrix representing the minority class data.
#' @return A list containing the original majority class data, original minority class data,
#' oversampled data, new dataset (combined original and oversampled data), and the original dataset.
#' @export
over_sampling <- function(major, minor) {
  # Calculate the pairwise distances between the minority class and majority class data
  distances <- dist(rbind(minor, major))

  # Randomly select two points from the minority class
  set.seed(123)  # Set seed for reproducibility
  sampled_points <- sample(1:nrow(minor), 2, replace = FALSE)

  # Calculate the shortest distance from each selected point to the majority class data boundary
  shortest_distances <- apply(distances[sampled_points, nrow(minor) + 1:ncol(distances)], 2, min)

  # Generate new oversampled data
  oversampled_data <- minor
  while (nrow(oversampled_data) < nrow(major)) {
    # Select two points from the minority class within the distance constraint
    new_points <- numeric()
    while (length(new_points) < 2) {
      new_points <- sample(1:nrow(minor), 2, replace = FALSE)
      if (all(distances[new_points[1], nrow(minor) + 1:ncol(distances)] <= shortest_distances) &
          all(distances[new_points[2], nrow(minor) + 1:ncol(distances)] <= shortest_distances)) {
        break
      }
    }

    # Generate new data point by taking the midpoint of the line connecting the two selected points
    new_data_point <- rowMeans(minor[new_points, ])

    # Append new data point to the oversampled data
    oversampled_data <- rbind(oversampled_data, new_data_point)
  }

  # Combine original and oversampled data
  new_dataset <- rbind(major, oversampled_data)

  # Return the results as a list
  result <- list(original_major = major,
                 original_minor = minor,
                 oversampled_data = oversampled_data,
                 new_dataset = new_dataset,
                 original_dataset = rbind(major, minor))
  return(result)
}

